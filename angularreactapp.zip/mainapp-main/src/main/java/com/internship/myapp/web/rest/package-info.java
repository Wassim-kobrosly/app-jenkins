/**
 * Spring MVC REST controllers.
 */
package com.internship.myapp.web.rest;
