/**
 * JPA domain objects.
 */
package com.internship.myapp.domain;
