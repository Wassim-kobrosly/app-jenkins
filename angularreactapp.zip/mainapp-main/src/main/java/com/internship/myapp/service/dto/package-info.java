/**
 * Data Transfer Objects.
 */
package com.internship.myapp.service.dto;
