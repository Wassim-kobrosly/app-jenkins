/**
 * Spring Security configuration.
 */
package com.internship.myapp.security;
