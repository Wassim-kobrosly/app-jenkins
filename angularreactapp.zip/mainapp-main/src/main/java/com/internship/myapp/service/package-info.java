/**
 * Service layer beans.
 */
package com.internship.myapp.service;
