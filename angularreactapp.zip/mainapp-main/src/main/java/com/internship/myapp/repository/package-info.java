/**
 * Spring Data JPA repositories.
 */
package com.internship.myapp.repository;
